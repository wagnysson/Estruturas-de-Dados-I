#ifndef UTIL_H
#define UTIL_H

#define POSITIVO 0;
#define NEGATIVO 1;
#define TRUE 2;
#define FALSE 3;

typedef int boolean;

char *readLine();
void boolean_print(boolean bool);

#endif //UTIL_H
