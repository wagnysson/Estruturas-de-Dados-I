#ifndef _PONTO_H_
#define _PONTO_H_

typedef struct _ponto PONTO;

PONTO *ler_ponto();
float distancia_pontos(PONTO *a, PONTO *b);

#endif